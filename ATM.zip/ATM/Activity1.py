import tkinter as tk
from tkinter import messagebox, simpledialog
from PIL import Image, ImageTk 

# Initial setup
correct_pin = "1234"
balance = 1000.0
attempts_left = 3


class ATMApp:
    def __init__(self, root):
        self.root = root
        self.root.title("ATM Simulation")
        self.root.geometry("1100x1100")
        self.root.configure(bg="#1e1e1e")

        #Load and display the image banner
        atm_image = Image.open("image.jpeg")  
        atm_image = atm_image.resize((1100, 250))  
        self.atm_photo = ImageTk.PhotoImage(atm_image)

        self.banner_label = tk.Label(root, image=self.atm_photo, bg="#1e1e1e")
        self.banner_label.pack(fill="x")  


        self.title_label = tk.Label(root, text="Welcome, Please login below", font=("Arial", 18, "bold"), fg="white", bg="#1e1e1e")
        self.title_label.pack(pady=(40, 20))  


        self.login_button = tk.Button(root, text="LOGIN", font=("Arial", 14), bg="#e53935", fg="white", width=15, height=2, command=self.login_screen)
        self.login_button.pack()

    def login_screen(self):
        global attempts_left
        while attempts_left > 0:
            pin = simpledialog.askstring("PIN Login", "Enter your 4-digit PIN:", show="*")
            if pin is None:
                return  
            if pin == correct_pin:
                messagebox.showinfo("Success", "Login successful!")
                self.root.destroy()
                self.open_atm_menu()
                return
            else:
                attempts_left -= 1
                messagebox.showerror("Incorrect", f"Incorrect PIN. {attempts_left} attempt(s) left.")
        
        messagebox.showerror("Blocked", "Too many incorrect attempts. Card blocked.")
        self.root.destroy()

    def open_atm_menu(self):
        self.menu_window = tk.Tk()
        self.menu_window.title("ATM Menu")
        self.menu_window.geometry("1000x1000")
        self.menu_window.configure(bg="#121212")

        self.balance = balance  # Set initial balance

        atm_image = Image.open("image.jpeg")  
        atm_image = atm_image.resize((1100, 250))  
        self.atm_photo = ImageTk.PhotoImage(atm_image)

        self.banner_label = tk.Label(self.menu_window, image=self.atm_photo, bg="#1e1e1e")
        self.banner_label.pack(fill="x")  

        self.title = tk.Label(self.menu_window, text="Reabetswe Tsotetsi", font=("Arial", 18, "bold"),
                      fg="white", bg="#121212")
        self.title.pack(pady=20)
        self.title = tk.Label(self.menu_window, text="🏧 ATM MENU", font=("Arial", 18, "bold"),
                      fg="white", bg="#121212")
        self.title.pack(pady=20)

# Menu buttons
        tk.Button(self.menu_window, text="1. Check Balance", font=("Arial", 14), width=30,
        bg="red", fg="white", command=self.check_balance).pack(pady=5)

        tk.Button(self.menu_window, text="2. Deposit Money", font=("Arial", 14), width=30,
          bg="red", fg="white", command=self.deposit_money).pack(pady=5)

        tk.Button(self.menu_window, text="3. Withdraw Money", font=("Arial", 14), width=30,
          bg="red", fg="white", command=self.withdraw_money).pack(pady=5)

        tk.Button(self.menu_window, text="4. Exit", font=("Arial", 14), width=30,
          bg="red", fg="white", command=self.menu_window.destroy).pack(pady=5)

    def check_balance(self):
         messagebox.showinfo("Balance", f"Your current balance is: R{self.balance:.2f}")

    def deposit_money(self):
        try:
            amount = simpledialog.askfloat("Deposit", "Enter amount to deposit:")
            if amount is not None:
                if amount > 0:
                    self.balance += amount
                    messagebox.showinfo("Success", f"R{amount:.2f} deposited successfully.")
                else:
                    messagebox.showerror("Error", "Invalid deposit amount.")
        except:
            messagebox.showerror("Error", "Invalid input.")

    def withdraw_money(self):
        try:
            amount = simpledialog.askfloat("Withdraw", "Enter amount to withdraw:")
            if amount is not None:
                if amount <= 0:
                    messagebox.showerror("Error", "Invalid withdrawal amount.")
                elif amount <= self.balance:
                    self.balance -= amount
                    messagebox.showinfo("Success", f"R{amount:.2f} withdrawn successfully.")
                else:
                    messagebox.showerror("Error", "Insufficient funds.")
        except:
            messagebox.showerror("Error", "Invalid input.")


# Run the app
if __name__ == "__main__":
    root = tk.Tk()
    app = ATMApp(root)
    root.mainloop()
