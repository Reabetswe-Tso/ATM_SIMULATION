import tkinter as tk
from tkinter import messagebox
import random

# Quiz questions
questions = [
    {
        "question": "What is the capital of South Africa?",
        "choices": ["A. Johannesburg", "B. Cape Town", "C. Pretoria", "D. Durban"],
        "answer": "C"
    },
    {
        "question": "Which language is primarily used for web development?",
        "choices": ["A. Python", "B. HTML", "C. C++", "D. Java"],
        "answer": "B"
    },
    {
        "question": "What does CPU stand for?",
        "choices": ["A. Central Performance Unit", "B. Central Processing Unit", "C. Computer Processing Unit", "D. Control Program Unit"],
        "answer": "B"
    },
    {
        "question": "Which planet is known as the Red Planet?",
        "choices": ["A. Mars", "B. Venus", "C. Jupiter", "D. Saturn"],
        "answer": "A"
    },
    {
        "question": "Who wrote 'Romeo and Juliet'?",
        "choices": ["A. Charles Dickens", "B. William Shakespeare", "C. Mark Twain", "D. Jane Austen"],
        "answer": "B"
    }
]

random.shuffle(questions)


class QuizApp:
    def __init__(self, master):
        self.master = master
        master.title("Quiz App")
        master.geometry("500x400")
        master.configure(bg="#ed87ed")

        self.score = 0
        self.q_index = 0

        self.question_label = tk.Label(master, text="", font=("Arial", 16), wraplength=400, bg="#f4f4f4")
        self.question_label.pack(pady=30)

        self.buttons = []
        for i in range(4):
            btn = tk.Button(master, text="", font=("Arial", 14), width=30, command=lambda idx=i: self.check_answer(idx))
            btn.pack(pady=5)
            self.buttons.append(btn)

        self.display_question()

    def display_question(self):
        if self.q_index < len(questions):
            q = questions[self.q_index]
            self.question_label.config(text=f"Q{self.q_index + 1}: {q['question']}")
            for i, choice in enumerate(q["choices"]):
                self.buttons[i].config(text=choice)
        else:
            self.show_result()

    def check_answer(self, index):
        selected = self.buttons[index].cget("text")[0]  # Get 'A', 'B', etc.
        correct = questions[self.q_index]["answer"]

        if selected == correct:
            self.score += 1
            messagebox.showinfo("Correct ✅", "That's the correct answer!")
        else:
            messagebox.showerror("Wrong ❌", f"Oops! The correct answer was {correct}.")

        self.q_index += 1
        self.display_question()

    def show_result(self):
        msg = f"Quiz Complete!\nYour final score is {self.score}/{len(questions)}"
        if self.score == len(questions):
            msg += "\n🎉 Excellent work! You're a quiz master!"
        elif self.score >= len(questions) // 2:
            msg += "\n👏 Well done!"
        else:
            msg += "\n📚 Keep practicing!"
        messagebox.showinfo("Result", msg)
        self.master.destroy()


# Landing page class
class LandingPage:
    def __init__(self, root):
        self.root = root
        root.title("Quiz App - Welcome")
        root.geometry("500x400")
        root.configure(bg="#eb7bde")

        self.title = tk.Label(root, text="Welcome to the Quiz Challenge!", font=("Arial", 18, "bold"), bg="#fae0f0")
        self.title.pack(pady=80)

        self.start_btn = tk.Button(root, text="Start Quiz ▶", font=("Arial", 14), bg="#4caf50", fg="white",
                                   padx=20, pady=10, command=self.start_quiz)
        self.start_btn.pack()

    def start_quiz(self):
        self.root.destroy()
        quiz_window = tk.Tk()
        QuizApp(quiz_window)
        quiz_window.mainloop()


# Run the landing page
if __name__ == "__main__":
    root = tk.Tk()
    app = LandingPage(root)
    root.mainloop()
